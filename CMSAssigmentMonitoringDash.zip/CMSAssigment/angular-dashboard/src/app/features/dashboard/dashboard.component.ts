import {
  Component, OnInit, OnDestroy, ChangeDetectionStrategy,
  ChangeDetectorRef, signal
} from '@angular/core';
import { CommonModule, AsyncPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subject, combineLatest } from 'rxjs';
import { takeUntil, map } from 'rxjs/operators';
import { DashboardService } from '../../core/services/dashboard.service';
import { AuthService } from '../../core/services/auth.service';
import { ThemeService } from '../../core/services/theme.service';
import { KpiCardComponent } from '../../shared/components/kpi-card/kpi-card.component';
import { TableComponent } from '../../shared/components/table/table.component';
import { ChartComponent } from '../../shared/components/chart/chart.component';
import { Alert, TableColumn } from '../../shared/models/dashboard.models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule, AsyncPipe, FormsModule,
    KpiCardComponent, TableComponent, ChartComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  state$ = this.dashboardSvc.state$;
  filteredAlerts$ = this.dashboardSvc.filteredAlerts$;
  liveKpis$ = this.dashboardSvc.liveKpis$;
  realtimeMetrics$ = this.dashboardSvc.realtimeMetrics$;
  alertStats$ = this.dashboardSvc.getAlertStats();
  userStats$ = this.dashboardSvc.getUserStats();

  sidebarOpen = signal(true);
  realTimeActive = signal(true);
  activeTab = signal<'alerts' | 'users'>('alerts');

  // Filter state
  filterSearch = '';
  filterStatus = '';
  filterType = '';
  filterCategory = '';

  // Chart data
  lineChartData: any = { labels: [], datasets: [] };
  barChartData: any = { labels: [], datasets: [] };
  pieChartData: any = { labels: [], datasets: [] };
  userPieData: any = { labels: [], datasets: [] };

  alertColumns: TableColumn[] = [
    { key: 'id', label: '#', sortable: true, type: 'number' },
    { key: 'type', label: 'Type', sortable: true, type: 'badge' },
    { key: 'message', label: 'Message', sortable: false, type: 'text' },
    { key: 'source', label: 'Source', sortable: true, type: 'text' },
    { key: 'category', label: 'Category', sortable: true, type: 'text' },
    { key: 'status', label: 'Status', sortable: true, type: 'badge' },
    { key: 'timestamp', label: 'Time', sortable: true, type: 'date' }
  ];

  userColumns: TableColumn[] = [
    { key: 'name', label: 'Name', sortable: true },
    { key: 'email', label: 'Email', sortable: true },
    { key: 'role', label: 'Role', sortable: true },
    { key: 'status', label: 'Status', sortable: true, type: 'badge' },
    { key: 'location', label: 'Location', sortable: true },
    { key: 'sessions', label: 'Sessions', sortable: true, type: 'number' },
    { key: 'lastActivity', label: 'Last Active', sortable: true, type: 'date' }
  ];

  constructor(
    public dashboardSvc: DashboardService,
    public authSvc: AuthService,
    public themeSvc: ThemeService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    // Build bar chart from static data
    this.barChartData = {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [
        { label: 'Critical', data: [12, 8, 15, 6, 10, 4, 7], backgroundColor: '#ef4444' },
        { label: 'Warning', data: [20, 18, 25, 14, 22, 10, 16], backgroundColor: '#f59e0b' },
        { label: 'Info', data: [30, 25, 35, 28, 32, 18, 24], backgroundColor: '#4f46e5' }
      ]
    };

    // Build pie from alert stats
    this.alertStats$.pipe(takeUntil(this.destroy$)).subscribe(stats => {
      this.pieChartData = {
        labels: ['Critical', 'Warning', 'Info', 'Resolved'],
        datasets: [{
          data: [stats.critical, stats.warning, stats.info, stats.resolved],
          backgroundColor: ['#ef4444', '#f59e0b', '#4f46e5', '#10b981'],
          borderWidth: 0
        }]
      };
      this.cdr.markForCheck();
    });

    this.userStats$.pipe(takeUntil(this.destroy$)).subscribe(stats => {
      this.userPieData = {
        labels: ['Online', 'Idle', 'Offline'],
        datasets: [{
          data: [stats.online, stats.idle, stats.offline],
          backgroundColor: ['#10b981', '#f59e0b', '#94a3b8'],
          borderWidth: 0
        }]
      };
      this.cdr.markForCheck();
    });

    // Build real-time line chart from metrics
    this.realtimeMetrics$.pipe(takeUntil(this.destroy$)).subscribe(metrics => {
      this.lineChartData = {
        labels: metrics.map(m => m.timestamp.toLocaleTimeString()),
        datasets: [
          {
            label: 'CPU %',
            data: metrics.map(m => m.cpu.toFixed(1)),
            borderColor: '#4f46e5',
            backgroundColor: 'rgba(79,70,229,0.1)',
            tension: 0.4, fill: true, borderWidth: 2, pointRadius: 0
          },
          {
            label: 'Memory %',
            data: metrics.map(m => m.memory.toFixed(1)),
            borderColor: '#06b6d4',
            backgroundColor: 'rgba(6,182,212,0.1)',
            tension: 0.4, fill: true, borderWidth: 2, pointRadius: 0
          },
          {
            label: 'Network %',
            data: metrics.map(m => m.network.toFixed(1)),
            borderColor: '#10b981',
            backgroundColor: 'rgba(16,185,129,0.05)',
            tension: 0.4, fill: false, borderWidth: 2, pointRadius: 0
          }
        ]
      };
      this.cdr.markForCheck();
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onFilterChange(): void {
    this.dashboardSvc.updateFilter({
      search: this.filterSearch,
      status: this.filterStatus,
      type: this.filterType,
      category: this.filterCategory
    });
  }

  resetFilters(): void {
    this.filterSearch = '';
    this.filterStatus = '';
    this.filterType = '';
    this.filterCategory = '';
    this.dashboardSvc.resetFilters();
  }

  toggleRealTime(): void {
    const val = !this.realTimeActive();
    this.realTimeActive.set(val);
    this.dashboardSvc.toggleRealTime(val);
  }

  onRowAction(event: { action: string; row: Alert }): void {
    if (event.action === 'acknowledge') {
      this.dashboardSvc.acknowledgeAlert(event.row.id);
    } else if (event.action === 'resolve') {
      this.dashboardSvc.resolveAlert(event.row.id);
    }
  }

  logout(): void {
    this.authSvc.logout();
  }
}
