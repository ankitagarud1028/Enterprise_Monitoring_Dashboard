package com.whiteboard.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.whiteboard.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * Adapter for listing saved whiteboard JSON files.
 */
class SavedWhiteboardsAdapter(
    private val files: MutableList<File>,
    private val onOpen: (File) -> Unit,
    private val onDelete: (File) -> Unit
) : RecyclerView.Adapter<SavedWhiteboardsAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView      = view.findViewById(R.id.tvFileName)
        val tvDate: TextView      = view.findViewById(R.id.tvFileDate)
        val btnOpen: TextView     = view.findViewById(R.id.btnOpenFile)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDeleteFile)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_saved_whiteboard, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val file = files[position]
        holder.tvName.text = file.name
        val sdf = SimpleDateFormat("dd MMM yyyy  HH:mm", Locale.getDefault())
        holder.tvDate.text = sdf.format(Date(file.lastModified()))
        holder.btnOpen.setOnClickListener { onOpen(file) }
        holder.btnDelete.setOnClickListener {
            onDelete(file)
            files.removeAt(position)
            notifyItemRemoved(position)
        }
    }

    override fun getItemCount() = files.size

    fun updateFiles(newFiles: List<File>) {
        files.clear()
        files.addAll(newFiles)
        notifyDataSetChanged()
    }
}
