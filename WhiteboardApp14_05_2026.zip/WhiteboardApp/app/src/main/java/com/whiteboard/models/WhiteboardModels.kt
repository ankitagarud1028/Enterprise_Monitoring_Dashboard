package com.whiteboard.models

import com.google.gson.annotations.SerializedName

// ─── Stroke (freehand drawing) ───────────────────────────────────────────────

data class StrokePoint(
    @SerializedName("x") val x: Float,
    @SerializedName("y") val y: Float
)

data class Stroke(
    @SerializedName("id") val id: String,
    @SerializedName("points") val points: MutableList<StrokePoint> = mutableListOf(),
    @SerializedName("color") var color: Int,
    @SerializedName("width") var width: Float,
    @SerializedName("isEraser") val isEraser: Boolean = false
)

// ─── Shape ───────────────────────────────────────────────────────────────────

enum class ShapeType { RECTANGLE, CIRCLE, LINE, POLYGON }

data class WhiteboardShape(
    @SerializedName("id") val id: String,
    @SerializedName("type") val type: ShapeType,
    @SerializedName("startX") var startX: Float,
    @SerializedName("startY") var startY: Float,
    @SerializedName("endX") var endX: Float,
    @SerializedName("endY") var endY: Float,
    @SerializedName("color") var color: Int,
    @SerializedName("strokeWidth") var strokeWidth: Float = 4f,
    @SerializedName("sides") val sides: Int = 6
)

// ─── Text ─────────────────────────────────────────────────────────────────────

data class WhiteboardText(
    @SerializedName("id") val id: String,
    @SerializedName("text") var text: String,
    @SerializedName("x") var x: Float,
    @SerializedName("y") var y: Float,
    @SerializedName("color") var color: Int,
    @SerializedName("fontSize") var fontSize: Float = 40f
)

// ─── Canvas State (serialised to JSON) ───────────────────────────────────────

data class WhiteboardState(
    @SerializedName("version") val version: Int = 1,
    @SerializedName("createdAt") val createdAt: Long = System.currentTimeMillis(),
    @SerializedName("strokes") val strokes: MutableList<Stroke> = mutableListOf(),
    @SerializedName("shapes") val shapes: MutableList<WhiteboardShape> = mutableListOf(),
    @SerializedName("texts") val texts: MutableList<WhiteboardText> = mutableListOf()
)

// ─── Tool Enum ────────────────────────────────────────────────────────────────

enum class DrawingTool {
    PEN, ERASER, RECTANGLE, CIRCLE, LINE, POLYGON, TEXT, SELECT
}

// ─── Undo / Redo Action ───────────────────────────────────────────────────────

sealed class UndoAction {
    data class AddStroke(val stroke: Stroke) : UndoAction()
    data class AddShape(val shape: WhiteboardShape) : UndoAction()
    data class AddText(val text: WhiteboardText) : UndoAction()
    data class RemoveStroke(val stroke: Stroke) : UndoAction()
    data class RemoveShape(val shape: WhiteboardShape) : UndoAction()
    data class RemoveText(val text: WhiteboardText) : UndoAction()
    data class MoveText(
        val text: WhiteboardText,
        val oldX: Float, val oldY: Float,
        val newX: Float, val newY: Float
    ) : UndoAction()
    object ClearAll : UndoAction()
}
