import { Injectable } from '@angular/core';
import {
  BehaviorSubject, Subject, Observable, combineLatest, interval, of, EMPTY
} from 'rxjs';
import {
  switchMap, debounceTime, map, takeUntil, shareReplay,
  catchError, startWith, distinctUntilChanged, scan, tap
} from 'rxjs/operators';
import {
  Alert, ActiveUser, SystemMetric, KpiCard,
  DashboardState, FilterConfig
} from '../../shared/models/dashboard.models';
import { MockDataService } from './mock-data.service';

@Injectable({ providedIn: 'root' })
export class DashboardService {
  private destroy$ = new Subject<void>();

  // State subjects
  private stateSubject = new BehaviorSubject<DashboardState>({
    kpis: [],
    alerts: [],
    metrics: [],
    users: [],
    loading: true,
    error: null,
    lastUpdated: null
  });

  private filterSubject = new BehaviorSubject<FilterConfig>({
    search: '', status: '', type: '', category: ''
  });

  private realTimeSubject = new BehaviorSubject<boolean>(true);
  private metricsBuffer: SystemMetric[] = [];
  private allAlerts: Alert[] = [];
  private allUsers: ActiveUser[] = [];

  // Public observables
  state$ = this.stateSubject.asObservable();
  filter$ = this.filterSubject.asObservable();

  // Derived: filtered alerts using combineLatest + debounceTime
  filteredAlerts$: Observable<Alert[]> = combineLatest([
    this.state$.pipe(map(s => s.alerts)),
    this.filter$.pipe(debounceTime(300), distinctUntilChanged())
  ]).pipe(
    map(([alerts, filter]) => this.applyFilters(alerts, filter)),
    shareReplay(1)
  );

  // Real-time metrics stream
  realtimeMetrics$: Observable<SystemMetric[]> = this.realTimeSubject.pipe(
    switchMap(active => active
      ? interval(2000).pipe(
          startWith(0),
          map(() => {
            const m = this.mockData.generateMetric();
            this.metricsBuffer = [...this.metricsBuffer.slice(-29), m];
            return [...this.metricsBuffer];
          })
        )
      : EMPTY
    ),
    shareReplay(1)
  );

  // KPI refresh stream
  liveKpis$: Observable<KpiCard[]> = interval(5000).pipe(
    startWith(0),
    map(() => this.mockData.generateKpis()),
    shareReplay(1)
  );

  constructor(private mockData: MockDataService) {
    this.initializeDashboard();
  }

  private initializeDashboard(): void {
    this.allAlerts = this.mockData.generateAlerts(50);
    this.allUsers = this.mockData.generateUsers(25);

    // Simulate async data loading
    setTimeout(() => {
      this.updateState({
        kpis: this.mockData.generateKpis(),
        alerts: this.allAlerts,
        users: this.allUsers,
        loading: false,
        error: null,
        lastUpdated: new Date()
      });
    }, 1000);
  }

  private updateState(partial: Partial<DashboardState>): void {
    this.stateSubject.next({ ...this.stateSubject.value, ...partial });
  }

  private applyFilters(alerts: Alert[], filter: FilterConfig): Alert[] {
    return alerts.filter(a => {
      const matchSearch = !filter.search ||
        a.message.toLowerCase().includes(filter.search.toLowerCase()) ||
        a.source.toLowerCase().includes(filter.search.toLowerCase());
      const matchStatus = !filter.status || a.status === filter.status;
      const matchType = !filter.type || a.type === filter.type;
      const matchCat = !filter.category || a.category === filter.category;
      return matchSearch && matchStatus && matchType && matchCat;
    });
  }

  updateFilter(partial: Partial<FilterConfig>): void {
    this.filterSubject.next({ ...this.filterSubject.value, ...partial });
  }

  resetFilters(): void {
    this.filterSubject.next({ search: '', status: '', type: '', category: '' });
  }

  toggleRealTime(active: boolean): void {
    this.realTimeSubject.next(active);
  }

  acknowledgeAlert(id: number): void {
    const alerts = this.stateSubject.value.alerts.map(a =>
      a.id === id ? { ...a, status: 'acknowledged' as const } : a
    );
    this.allAlerts = alerts;
    this.updateState({ alerts });
  }

  resolveAlert(id: number): void {
    const alerts = this.stateSubject.value.alerts.map(a =>
      a.id === id ? { ...a, status: 'resolved' as const } : a
    );
    this.allAlerts = alerts;
    this.updateState({ alerts });
  }

  getAlertStats(): Observable<{ critical: number; warning: number; info: number; resolved: number }> {
    return this.state$.pipe(
      map(s => ({
        critical: s.alerts.filter(a => a.type === 'critical' && a.status === 'active').length,
        warning: s.alerts.filter(a => a.type === 'warning' && a.status === 'active').length,
        info: s.alerts.filter(a => a.type === 'info').length,
        resolved: s.alerts.filter(a => a.status === 'resolved').length
      }))
    );
  }

  getUserStats(): Observable<{ online: number; idle: number; offline: number }> {
    return this.state$.pipe(
      map(s => ({
        online: s.users.filter(u => u.status === 'online').length,
        idle: s.users.filter(u => u.status === 'idle').length,
        offline: s.users.filter(u => u.status === 'offline').length
      }))
    );
  }

  destroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
