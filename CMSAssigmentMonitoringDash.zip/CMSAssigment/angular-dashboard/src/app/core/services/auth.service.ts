import { Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, of, throwError } from 'rxjs';
import { delay, tap, map } from 'rxjs/operators';
import { User, LoginCredentials } from '../../shared/models/dashboard.models';

const MOCK_USERS: User[] = [
  { id: 1, username: 'admin', email: 'admin@company.com', role: 'admin', token: 'mock-jwt-token-admin-xyz' },
  { id: 2, username: 'viewer', email: 'viewer@company.com', role: 'viewer', token: 'mock-jwt-token-viewer-xyz' }
];

@Injectable({ providedIn: 'root' })
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User | null>(this.loadUser());
  public currentUser$ = this.currentUserSubject.asObservable();
  isLoggedIn = signal(!!this.loadUser());

  constructor(private router: Router) {}

  private loadUser(): User | null {
    try {
      const stored = localStorage.getItem('current_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  }

  login(credentials: LoginCredentials): Observable<User> {
    const user = MOCK_USERS.find(
      u => u.username === credentials.username && credentials.password === 'password123'
    );

    if (!user) {
      return throwError(() => new Error('Invalid username or password')).pipe(delay(800));
    }

    return of(user).pipe(
      delay(800),
      tap(u => {
        localStorage.setItem('auth_token', u.token || '');
        localStorage.setItem('current_user', JSON.stringify(u));
        this.currentUserSubject.next(u);
        this.isLoggedIn.set(true);
      })
    );
  }

  logout(): void {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('current_user');
    this.currentUserSubject.next(null);
    this.isLoggedIn.set(false);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    return localStorage.getItem('auth_token');
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }
}
