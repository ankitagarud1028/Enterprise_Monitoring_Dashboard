// Auth Models
export interface User {
  id: number;
  username: string;
  email: string;
  role: 'admin' | 'viewer';
  token?: string;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

// Dashboard Models
export interface KpiCard {
  id: string;
  title: string;
  value: number | string;
  change: number;
  changeType: 'increase' | 'decrease';
  icon: string;
  color: string;
  unit?: string;
}

export interface Alert {
  id: number;
  type: 'critical' | 'warning' | 'info';
  message: string;
  source: string;
  timestamp: Date;
  status: 'active' | 'resolved' | 'acknowledged';
  category: string;
}

export interface SystemMetric {
  timestamp: Date;
  cpu: number;
  memory: number;
  network: number;
  disk: number;
}

export interface ActiveUser {
  id: number;
  name: string;
  email: string;
  role: string;
  status: 'online' | 'idle' | 'offline';
  lastActivity: Date;
  location: string;
  sessions: number;
}

export interface TableColumn {
  key: string;
  label: string;
  sortable?: boolean;
  type?: 'text' | 'badge' | 'date' | 'number';
}

export interface PaginationConfig {
  page: number;
  pageSize: number;
  total: number;
}

export interface FilterConfig {
  search: string;
  status: string;
  type: string;
  category: string;
}

export interface DashboardState {
  kpis: KpiCard[];
  alerts: Alert[];
  metrics: SystemMetric[];
  users: ActiveUser[];
  loading: boolean;
  error: string | null;
  lastUpdated: Date | null;
}
