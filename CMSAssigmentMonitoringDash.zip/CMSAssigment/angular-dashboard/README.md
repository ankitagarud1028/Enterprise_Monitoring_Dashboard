# Enterprise Monitoring Dashboard

A production-ready Angular 17 dashboard with real-time metrics, RxJS reactive programming, authentication, lazy loading, and dark/light theming.

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm start

# 3. Open browser
http://localhost:4200
```

### Demo Login
| Field    | Value         |
|----------|---------------|
| Username | `admin`       |
| Password | `password123` |

---

## Project Architecture

```
src/app/
├── core/                        # Singleton services & guards
│   ├── guards/
│   │   └── auth.guard.ts        # Route protection (CanActivateFn)
│   ├── interceptors/
│   │   └── auth.interceptor.ts  # JWT token injection + 401 handling
│   └── services/
│       ├── auth.service.ts      # Login, logout, token management
│       ├── dashboard.service.ts # RxJS state management
│       ├── mock-data.service.ts # Mock API data generator
│       └── theme.service.ts     # Dark/Light theme toggle
│
├── shared/                      # Reusable components & models
│   ├── components/
│   │   ├── kpi-card/            # KPI metric card (OnPush)
│   │   ├── table/               # Sortable, paginated, filterable table (OnPush)
│   │   └── chart/               # Chart.js wrapper (line/bar/pie/doughnut)
│   └── models/
│       └── dashboard.models.ts  # All TypeScript interfaces
│
├── features/                    # Lazy-loaded feature modules
│   ├── auth/login/              # Login page
│   └── dashboard/               # Main dashboard
│
├── app.routes.ts                # Lazy loading routes
├── app.config.ts                # App providers (HTTP, Router, Animations)
└── app.component.ts             # Root shell
```

---

## Feature Implementation

### Authentication
- Mock login with token stored in `localStorage`
- `AuthGuard` protects `/dashboard` route
- `AuthInterceptor` adds `Authorization: Bearer <token>` to all HTTP requests
- Auto-redirect to `/login` on 401 response

### Reactive Programming (RxJS)
| Operator | Where used |
|---|---|
| `BehaviorSubject` | Dashboard state, filter state |
| `Subject` | Destroy lifecycle, real-time toggle |
| `combineLatest` | Merging alerts + filters |
| `switchMap` | Switching real-time interval on/off |
| `debounceTime` | Filter input debouncing (300ms) |
| `distinctUntilChanged` | Prevent duplicate filter emissions |
| `shareReplay(1)` | Shared observable caching |
| `interval` | Real-time polling (2s metrics, 5s KPIs) |
| `startWith` | Emit immediately before interval |
| `takeUntil` | Clean subscription teardown |

### Performance Optimizations
| Technique | Applied to |
|---|---|
| `ChangeDetectionStrategy.OnPush` | KpiCard, Table, Chart components |
| Lazy loading | `/login` and `/dashboard` routes |
| `trackBy` | Table rows `trackByIndex()` |
| `shareReplay(1)` | Metrics and KPI streams |
| Signal-based state | Sidebar, theme, real-time toggle |

### Dashboard UI
- **4 KPI cards** – Total Alerts, Active Users, System Health, Uptime
- **Real-time line chart** – CPU / Memory / Network (2s updates)
- **Bar chart** – Weekly alert volume by severity
- **Doughnut chart** – Alert distribution by type
- **Pie chart** – User status (Online/Idle/Offline)
- **Alerts table** – Sortable, paginated, filterable; acknowledge/resolve actions
- **Users table** – Sortable, paginated with search
- **Multi-filter bar** – Search + Status + Type + Category with debounce
- **Dark/Light theme** – Persisted to localStorage
- **Responsive layout** – Collapsible sidebar, mobile-friendly grids

### Advanced Feature Implemented
✅ **Real-time data simulation** – `interval(2000)` drives live CPU/Memory/Network charts with a 30-point rolling buffer. Toggle pause/resume from the topbar.

---

## Assumptions
- Mock API is simulated via `MockDataService` (no json-server needed to run)
- Token is a plain string stored in localStorage (production would use HttpOnly cookies)
- Chart.js is used directly via `chart.js` npm package (lighter than ng2-charts wrapper)
- Dark theme persists across sessions via localStorage

---

## Dependencies
| Package | Purpose |
|---|---|
| `@angular/core` v17 | Framework (Standalone components, Signals) |
| `rxjs` ~7.8 | Reactive streams |
| `chart.js` v4 | Charts (line, bar, pie, doughnut) |

---

## Available Scripts
```bash
npm start        # Dev server at http://localhost:4200
npm run build    # Production build → dist/
npm test         # Unit tests
```
