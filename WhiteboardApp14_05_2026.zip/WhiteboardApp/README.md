# 🖍 Whiteboard IFP — Android Kotlin App

A full-featured whiteboard application built in **Kotlin** for **Interactive Flat Panel (IFP) devices** (65″–85″). All data is stored locally as `.json` files — no internet required.

---

## ✨ Feature List

| Feature | Status |
|---|---|
| Freehand drawing with pen | ✅ |
| Pixel-based eraser | ✅ |
| Stroke width control (slider) | ✅ |
| Color palette (7 colors) | ✅ |
| Insert Rectangle | ✅ |
| Insert Circle / Oval | ✅ |
| Insert Line | ✅ |
| Insert Polygon (configurable sides) | ✅ |
| Insert & edit text boxes | ✅ |
| Drag text to reposition | ✅ |
| Save canvas as `.json` | ✅ |
| Load saved whiteboard from file | ✅ |
| Undo / Redo stack | ✅ (Bonus) |
| Export canvas as PNG | ✅ (Bonus) |
| Clear all | ✅ |
| Landscape-only, IFP-optimised UI | ✅ |
| Fully offline — no internet needed | ✅ |

---

## 🏗 Architecture Overview (MVVM)

```
com.whiteboard/
├── models/
│   └── WhiteboardModels.kt       ← Data classes: Stroke, Shape, Text, State, UndoAction
├── services/
│   └── FileService.kt            ← JSON save/load, PNG export
├── views/
│   └── WhiteboardView.kt         ← Custom Canvas view, all touch/stylus handling
├── viewmodels/
│   └── WhiteboardViewModel.kt    ← State, tool settings, undo/redo stack (LiveData)
├── ui/
│   └── SavedWhiteboardsAdapter.kt ← RecyclerView adapter for file list dialog
└── MainActivity.kt               ← Wires ViewModel ↔ View, handles dialogs
```

### Data Flow
```
User Touch → WhiteboardView (renders + emits callback)
           → MainActivity (receives callback)
           → WhiteboardViewModel (updates state via LiveData)
           → WhiteboardView.setState() → invalidate() → re-draw
```

---

## 📁 File Format

Files are saved at:
```
/sdcard/Android/data/com.whiteboard/files/whiteboards/whiteboard_yyyyMMdd_HHmmss.json
```

### JSON Schema

```json
{
  "version": 1,
  "createdAt": 1700000000000,
  "strokes": [
    {
      "id": "uuid",
      "points": [{"x": 10.0, "y": 20.0}, ...],
      "color": -16776961,
      "width": 6.0,
      "isEraser": false
    }
  ],
  "shapes": [
    {
      "id": "uuid",
      "type": "RECTANGLE",
      "startX": 100.0, "startY": 100.0,
      "endX": 300.0, "endY": 200.0,
      "color": -65536,
      "strokeWidth": 4.0,
      "sides": 6
    }
  ],
  "texts": [
    {
      "id": "uuid",
      "text": "Hello IFP!",
      "x": 300.0, "y": 400.0,
      "color": -16777216,
      "fontSize": 40.0
    }
  ]
}
```

> **Note on colors:** Android stores colors as signed 32-bit integers (ARGB).  
> Example: `-16776961` = `#FF0000FF` = full-opacity Blue.

---

## 🔧 Setup & Build Instructions

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- Kotlin 1.9+
- Android SDK 34
- A physical IFP device or large-screen tablet/emulator

### Build Steps
```bash
# 1. Clone the repository
git clone https://github.com/your-org/WhiteboardApp.git
cd WhiteboardApp

# 2. Open in Android Studio
#    File → Open → select the WhiteboardApp folder

# 3. Sync Gradle
#    Android Studio will prompt — click "Sync Now"

# 4. Run on device
#    Select your IFP device in the device dropdown → Run ▶
```

### IFP Deployment
1. Enable **Developer Options** on the IFP device.
2. Enable **USB Debugging**.
3. Connect via USB or ADB over Wi-Fi:
   ```bash
   adb connect <IFP_IP>:5555
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```
4. The app forces **landscape orientation** and scales all UI with `dp`/`sp` — no extra configuration needed.

---

## 📐 Tech Stack

| Layer | Technology |
|---|---|
| Language | Kotlin 1.9 |
| Architecture | MVVM (ViewModel + LiveData) |
| Drawing | Android Canvas, Paint, Path |
| Serialization | Gson 2.10 |
| UI | ConstraintLayout, Material Components |
| Storage | App-specific external storage (no permissions on API 29+) |

---

## 🎁 Bonus Features Implemented

- **Undo / Redo** — full action stack with `sealed class UndoAction`
- **Export as PNG** — saves to `exports/` folder in app storage
- **Eraser with visual indicator** — circle outline shows erase radius

---

*Built for the Android Whiteboard IFP Assignment*
