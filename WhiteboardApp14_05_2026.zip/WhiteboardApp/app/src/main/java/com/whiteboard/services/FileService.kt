package com.whiteboard.services

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.whiteboard.models.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*


class FileService(private val context: Context) {

    private val gson = GsonBuilder().setPrettyPrinting().create()

    // ─── Directories ─────────────────────────────────────────────────────────

    private val saveDir: File
        get() = File(context.getExternalFilesDir(null), "whiteboards").also { it.mkdirs() }

    private val exportDir: File
        get() = File(context.getExternalFilesDir(null), "exports").also { it.mkdirs() }

    // ─── Save ─────────────────────────────────────────────────────────────────

    /**
     * Saves the whiteboard state as a JSON file.
     * Filename format: whiteboard_yyyyMMdd_HHmmss.json
     * Returns the absolute file path.
     */
    fun saveWhiteboard(state: WhiteboardState, existingFileName: String? = null): String {
        val fileName = existingFileName ?: generateFileName()
        val file = File(saveDir, fileName)
        file.writeText(serializeToAssignmentFormat(state))
        return file.absolutePath
    }

    private fun generateFileName(): String {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        return "whiteboard_${sdf.format(Date())}.json"
    }

    // ─── Load ─────────────────────────────────────────────────────────────────

    fun loadWhiteboard(filePath: String): WhiteboardState? {
        return try {
            parseJson(File(filePath).readText())
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun loadWhiteboardFromUri(uri: Uri): WhiteboardState? {
        return try {
            val json = context.contentResolver.openInputStream(uri)
                ?.bufferedReader()?.readText() ?: return null
            parseJson(json)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // ─── List / Delete ────────────────────────────────────────────────────────

    fun listSavedWhiteboards(): List<File> {
        return saveDir.listFiles { f -> f.extension == "json" }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    fun deleteWhiteboard(filePath: String): Boolean = File(filePath).delete()

    // ─── Export PNG ───────────────────────────────────────────────────────────

    fun exportAsPng(bitmap: Bitmap): String {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        val file = File(exportDir, "whiteboard_${sdf.format(Date())}.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return file.absolutePath
    }

    // =========================================================================
    // Serialization — writes the assignment-specified JSON format
    // =========================================================================

    private fun serializeToAssignmentFormat(state: WhiteboardState): String {
        val root = JsonObject()
        root.addProperty("version", state.version)
        root.addProperty("createdAt", state.createdAt)

        // ── Strokes ──────────────────────────────────────────────────────────
        val strokesArr = com.google.gson.JsonArray()
        state.strokes.forEach { stroke ->
            val s = JsonObject()
            val pts = com.google.gson.JsonArray()
            stroke.points.forEach { pt ->
                val pair = com.google.gson.JsonArray()
                pair.add(pt.x)
                pair.add(pt.y)
                pts.add(pair)
            }
            s.add("points", pts)
            s.addProperty("color", colorIntToHex(stroke.color))
            s.addProperty("width", stroke.width)
            s.addProperty("isEraser", stroke.isEraser)
            s.addProperty("id", stroke.id)
            strokesArr.add(s)
        }
        root.add("strokes", strokesArr)

        // ── Shapes ───────────────────────────────────────────────────────────
        val shapesArr = com.google.gson.JsonArray()
        state.shapes.forEach { shape ->
            val s = JsonObject()
            s.addProperty("id", shape.id)
            s.addProperty("type", shape.type.name.lowercase())

            // Assignment format uses topLeft/bottomRight for rect/circle,
            // and start/end points for line
            when (shape.type) {
                ShapeType.LINE -> {
                    val start = com.google.gson.JsonArray()
                    start.add(shape.startX); start.add(shape.startY)
                    val end = com.google.gson.JsonArray()
                    end.add(shape.endX); end.add(shape.endY)
                    s.add("start", start)
                    s.add("end", end)
                }
                else -> {
                    val tl = com.google.gson.JsonArray()
                    tl.add(minOf(shape.startX, shape.endX))
                    tl.add(minOf(shape.startY, shape.endY))
                    val br = com.google.gson.JsonArray()
                    br.add(maxOf(shape.startX, shape.endX))
                    br.add(maxOf(shape.startY, shape.endY))
                    s.add("topLeft", tl)
                    s.add("bottomRight", br)
                }
            }
            s.addProperty("color", colorIntToHex(shape.color))
            s.addProperty("strokeWidth", shape.strokeWidth)
            if (shape.type == ShapeType.POLYGON) s.addProperty("sides", shape.sides)
            shapesArr.add(s)
        }
        root.add("shapes", shapesArr)

        // ── Texts ─────────────────────────────────────────────────────────────
        val textsArr = com.google.gson.JsonArray()
        state.texts.forEach { text ->
            val t = JsonObject()
            t.addProperty("id", text.id)
            t.addProperty("text", text.text)
            val pos = com.google.gson.JsonArray()
            pos.add(text.x); pos.add(text.y)
            t.add("position", pos)
            t.addProperty("color", colorIntToHex(text.color))
            t.addProperty("size", text.fontSize)
            textsArr.add(t)
        }
        root.add("texts", textsArr)

        return gson.toJson(root)
    }

    // =========================================================================
    // Deserialization — auto-detects assignment format vs internal format
    // =========================================================================

    private fun parseJson(json: String): WhiteboardState {
        val root = JsonParser.parseString(json).asJsonObject
        return if (isAssignmentFormat(root)) {
            parseAssignmentFormat(root)
        } else {
            parseInternalFormat(json)
        }
    }

    /**
     * Detect assignment format by checking if strokes have hex color strings
     * and shapes have topLeft/bottomRight keys.
     */
    private fun isAssignmentFormat(root: JsonObject): Boolean {
        // Check strokes: assignment format uses "#RRGGBB" string colors
        val strokes = root.getAsJsonArray("strokes")
        if (strokes != null && strokes.size() > 0) {
            val first = strokes[0].asJsonObject
            if (first.has("color") && first.get("color").isJsonPrimitive) {
                val colorVal = first.get("color").asString
                if (colorVal.startsWith("#")) return true
            }
        }
        // Check shapes: assignment format uses topLeft key
        val shapes = root.getAsJsonArray("shapes")
        if (shapes != null && shapes.size() > 0) {
            if (shapes[0].asJsonObject.has("topLeft")) return true
        }
        // Check texts: assignment format uses position array and "size" key
        val texts = root.getAsJsonArray("texts")
        if (texts != null && texts.size() > 0) {
            if (texts[0].asJsonObject.has("position")) return true
        }
        return false
    }

    // ── Parse assignment format ───────────────────────────────────────────────

    private fun parseAssignmentFormat(root: JsonObject): WhiteboardState {
        val state = WhiteboardState(
            version   = root.get("version")?.asInt ?: 1,
            createdAt = root.get("createdAt")?.asLong ?: System.currentTimeMillis()
        )

        // Strokes
        root.getAsJsonArray("strokes")?.forEach { el ->
            val s = el.asJsonObject
            val points = mutableListOf<StrokePoint>()
            s.getAsJsonArray("points")?.forEach { pt ->
                val arr = pt.asJsonArray
                points.add(StrokePoint(arr[0].asFloat, arr[1].asFloat))
            }
            val isEraser = s.get("isEraser")?.asBoolean ?: false
            state.strokes.add(
                Stroke(
                    id       = s.get("id")?.asString ?: UUID.randomUUID().toString(),
                    points   = points,
                    color    = parseColor(s.get("color")?.asString ?: "#000000"),
                    width    = s.get("width")?.asFloat ?: 4f,
                    isEraser = isEraser
                )
            )
        }

        // Shapes
        root.getAsJsonArray("shapes")?.forEach { el ->
            val s = el.asJsonObject
            val typeStr = s.get("type")?.asString?.uppercase() ?: "RECTANGLE"
            val shapeType = try { ShapeType.valueOf(typeStr) } catch (e: Exception) { ShapeType.RECTANGLE }
            val color = parseColor(s.get("color")?.asString ?: "#000000")
            val strokeWidth = s.get("strokeWidth")?.asFloat ?: 4f
            val sides = s.get("sides")?.asInt ?: 6

            val startX: Float
            val startY: Float
            val endX: Float
            val endY: Float

            when (shapeType) {
                ShapeType.LINE -> {
                    val start = s.getAsJsonArray("start")
                    val end   = s.getAsJsonArray("end")
                    startX = start?.get(0)?.asFloat ?: 0f
                    startY = start?.get(1)?.asFloat ?: 0f
                    endX   = end?.get(0)?.asFloat   ?: 0f
                    endY   = end?.get(1)?.asFloat   ?: 0f
                }
                else -> {
                    val tl = s.getAsJsonArray("topLeft")
                    val br = s.getAsJsonArray("bottomRight")
                    startX = tl?.get(0)?.asFloat ?: 0f
                    startY = tl?.get(1)?.asFloat ?: 0f
                    endX   = br?.get(0)?.asFloat ?: 0f
                    endY   = br?.get(1)?.asFloat ?: 0f
                }
            }

            state.shapes.add(
                WhiteboardShape(
                    id          = s.get("id")?.asString ?: UUID.randomUUID().toString(),
                    type        = shapeType,
                    startX      = startX, startY = startY,
                    endX        = endX,   endY   = endY,
                    color       = color,
                    strokeWidth = strokeWidth,
                    sides       = sides
                )
            )
        }

        // Texts
        root.getAsJsonArray("texts")?.forEach { el ->
            val t = el.asJsonObject
            val pos = t.getAsJsonArray("position")
            state.texts.add(
                WhiteboardText(
                    id       = t.get("id")?.asString ?: UUID.randomUUID().toString(),
                    text     = t.get("text")?.asString ?: "",
                    x        = pos?.get(0)?.asFloat ?: 0f,
                    y        = pos?.get(1)?.asFloat ?: 0f,
                    color    = parseColor(t.get("color")?.asString ?: "#000000"),
                    fontSize = t.get("size")?.asFloat ?: 40f
                )
            )
        }

        return state
    }

    // ── Parse internal format (Gson-native) ───────────────────────────────────

    private fun parseInternalFormat(json: String): WhiteboardState {
        return try {
            gson.fromJson(json, WhiteboardState::class.java)
        } catch (e: Exception) {
            WhiteboardState()
        }
    }

    // ─── Colour helpers ───────────────────────────────────────────────────────

    private fun colorIntToHex(color: Int): String {
        return String.format("#%06X", 0xFFFFFF and color)
    }

    private fun parseColor(hex: String): Int {
        return try {
            Color.parseColor(hex)
        } catch (e: Exception) {
            Color.BLACK
        }
    }
}
