package com.whiteboard.views

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.whiteboard.models.*
import kotlin.math.*

class WhiteboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    // ─── Callbacks ───────────────────────────────────────────────────────────

    var onStrokeFinished: ((Stroke) -> Unit)? = null
    var onShapeFinished:  ((WhiteboardShape) -> Unit)? = null
    var onTextTapped:     ((Float, Float) -> Unit)? = null
    var onTextMoved:      ((String, Float, Float) -> Unit)? = null

    // ─── Tool State ──────────────────────────────────────────────────────────
    // These are set directly — they do NOT call setState() and do NOT redraw state.

    var currentTool:  DrawingTool = DrawingTool.PEN
    var currentColor: Int   = Color.BLACK
    var strokeWidth:  Float = 6f
    var eraserWidth:  Float = 40f
    var polygonSides: Int   = 6
    var fontSize:     Float = 40f

    // ─── Whiteboard state (source of truth) ──────────────────────────────────

    private var whiteboardState: WhiteboardState = WhiteboardState()

    // ─── In-progress drawing (not yet committed to state) ────────────────────

    private var activeStroke: Stroke? = null
    private val activeEraserPoints = mutableListOf<StrokePoint>()
    private var previewShape: WhiteboardShape? = null

    // ─── Touch tracking ──────────────────────────────────────────────────────

    private var lastTouchX = 0f
    private var lastTouchY = 0f

    // ─── Text drag ───────────────────────────────────────────────────────────

    private var draggingTextId: String? = null
    private var dragOffsetX = 0f
    private var dragOffsetY = 0f


    private var cacheBitmap: Bitmap? = null
    private var cacheCanvas: Canvas? = null
    private var cacheValid = false

    // ─── Paint objects ───────────────────────────────────────────────────────

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style      = Paint.Style.STROKE
        strokeCap  = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val shapePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style     = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
    }

    private val eraserIndicatorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style       = Paint.Style.STROKE
        color       = Color.GRAY
        strokeWidth = 2f
    }

    // ─── Size changed ────────────────────────────────────────────────────────

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cacheBitmap?.recycle()
        cacheBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        cacheCanvas = Canvas(cacheBitmap!!)
        cacheValid  = false
        invalidate()
    }

    // ─── Public setState — called ONLY when data changes ─────────────────────

    fun setState(state: WhiteboardState) {
        whiteboardState = state
        cacheValid = false   // <-- only thing that triggers a full re-render
        invalidate()
    }

    // ─── onDraw ──────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Rebuild cache if state changed
        if (!cacheValid) rebuildCache()

        // 1. Blit committed state bitmap
        cacheBitmap?.let { canvas.drawBitmap(it, 0f, 0f, null) }

        // 2. In-progress pen stroke
        activeStroke?.let { drawStrokePreview(canvas, it) }

        // 3. In-progress eraser trail (drawn as thick white line)
        if (activeEraserPoints.size >= 2) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style       = Paint.Style.STROKE
                strokeCap   = Paint.Cap.ROUND
                strokeJoin  = Paint.Join.ROUND
                color       = Color.WHITE
                strokeWidth = eraserWidth
            }
            canvas.drawPath(buildPath(activeEraserPoints), p)
        }

        // 4. Shape rubber-band preview
        previewShape?.let { renderShape(canvas, it) }

        // 5. All text items (always on top)
        whiteboardState.texts.forEach { renderText(canvas, it) }

        // 6. Eraser circle cursor
        if (currentTool == DrawingTool.ERASER) {
            canvas.drawCircle(lastTouchX, lastTouchY, eraserWidth / 2f, eraserIndicatorPaint)
        }
    }

    // ─── Cache rebuild ────────────────────────────────────────────────────────

    private fun rebuildCache() {
        val c = cacheCanvas ?: return
        c.drawColor(Color.WHITE)
        whiteboardState.strokes.forEach { renderStroke(c, it) }
        whiteboardState.shapes.forEach  { renderShape(c, it)  }
        cacheValid = true
    }

    // ─── Rendering ───────────────────────────────────────────────────────────

    private fun renderStroke(canvas: Canvas, stroke: Stroke) {
        if (stroke.points.size < 2) return
        val path = buildPath(stroke.points)
        if (stroke.isEraser) {
            // White paint = erase on white background (simple and reliable)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style       = Paint.Style.STROKE
                strokeCap   = Paint.Cap.ROUND
                strokeJoin  = Paint.Join.ROUND
                color       = Color.WHITE
                strokeWidth = stroke.width
            }
            canvas.drawPath(path, p)
        } else {
            strokePaint.color       = stroke.color
            strokePaint.strokeWidth = stroke.width
            canvas.drawPath(path, strokePaint)
        }
    }

    private fun drawStrokePreview(canvas: Canvas, stroke: Stroke) {
        if (stroke.points.size < 2) return
        strokePaint.color       = stroke.color
        strokePaint.strokeWidth = stroke.width
        canvas.drawPath(buildPath(stroke.points), strokePaint)
    }

    private fun buildPath(points: List<StrokePoint>): Path {
        val path = Path()
        path.moveTo(points[0].x, points[0].y)
        if (points.size == 1) {
            path.lineTo(points[0].x + 0.1f, points[0].y)
            return path
        }
        for (i in 1 until points.size - 1) {
            val mx = (points[i].x + points[i + 1].x) / 2f
            val my = (points[i].y + points[i + 1].y) / 2f
            path.quadTo(points[i].x, points[i].y, mx, my)
        }
        path.lineTo(points.last().x, points.last().y)
        return path
    }

    private fun renderShape(canvas: Canvas, shape: WhiteboardShape) {
        shapePaint.color       = shape.color
        shapePaint.strokeWidth = shape.strokeWidth
        val l = min(shape.startX, shape.endX)
        val t = min(shape.startY, shape.endY)
        val r = max(shape.startX, shape.endX)
        val b = max(shape.startY, shape.endY)
        when (shape.type) {
            ShapeType.RECTANGLE -> canvas.drawRect(l, t, r, b, shapePaint)
            ShapeType.CIRCLE    -> canvas.drawOval(l, t, r, b, shapePaint)
            ShapeType.LINE      -> canvas.drawLine(shape.startX, shape.startY, shape.endX, shape.endY, shapePaint)
            ShapeType.POLYGON   -> drawPolygon(canvas, shape)
        }
    }

    private fun drawPolygon(canvas: Canvas, shape: WhiteboardShape) {
        val cx    = (shape.startX + shape.endX) / 2f
        val cy    = (shape.startY + shape.endY) / 2f
        val r     = min(abs(shape.endX - shape.startX), abs(shape.endY - shape.startY)) / 2f
        val sides = shape.sides.coerceAtLeast(3)
        val path  = Path()
        for (i in 0 until sides) {
            val angle = (2.0 * PI * i / sides - PI / 2).toFloat()
            val px = cx + r * cos(angle)
            val py = cy + r * sin(angle)
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        canvas.drawPath(path, shapePaint)
    }

    private fun renderText(canvas: Canvas, text: WhiteboardText) {
        textPaint.color    = text.color
        textPaint.textSize = text.fontSize
        canvas.drawText(text.text, text.x, text.y, textPaint)
    }

    // ─── Touch handling ───────────────────────────────────────────────────────

    override fun onTouchEvent(event: MotionEvent): Boolean {
        lastTouchX = event.x
        lastTouchY = event.y
        return when (currentTool) {
            DrawingTool.PEN    -> handlePen(event)
            DrawingTool.ERASER -> handleEraser(event)
            DrawingTool.TEXT   -> handleText(event)
            DrawingTool.SELECT -> handleSelect(event)
            else               -> handleShape(event)
        }
    }

    // ── Pen ──────────────────────────────────────────────────────────────────

    private fun handlePen(event: MotionEvent): Boolean {
        val x = event.x; val y = event.y
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                activeStroke = Stroke(
                    id    = java.util.UUID.randomUUID().toString(),
                    color = currentColor,
                    width = strokeWidth
                ).also { it.points.add(StrokePoint(x, y)) }
            }
            MotionEvent.ACTION_MOVE -> {
                activeStroke?.points?.add(StrokePoint(x, y))
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                activeStroke?.let { s ->
                    s.points.add(StrokePoint(x, y))
                    onStrokeFinished?.invoke(s)   // ViewModel updates state → cacheValid=false
                }
                activeStroke = null
                invalidate()
            }
        }
        return true
    }

    // ── Eraser ───────────────────────────────────────────────────────────────

    private fun handleEraser(event: MotionEvent): Boolean {
        val x = event.x; val y = event.y
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                activeEraserPoints.clear()
                activeEraserPoints.add(StrokePoint(x, y))
            }
            MotionEvent.ACTION_MOVE -> {
                activeEraserPoints.add(StrokePoint(x, y))
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                activeEraserPoints.add(StrokePoint(x, y))
                if (activeEraserPoints.size >= 2) {
                    // Save as eraser stroke into ViewModel — survives tool switches!
                    val eraserStroke = Stroke(
                        id       = java.util.UUID.randomUUID().toString(),
                        points   = activeEraserPoints.toMutableList(),
                        color    = Color.WHITE,
                        width    = eraserWidth,
                        isEraser = true
                    )
                    onStrokeFinished?.invoke(eraserStroke)
                }
                activeEraserPoints.clear()
                invalidate()
            }
        }
        return true
    }

    // ── Shapes ───────────────────────────────────────────────────────────────

    private fun handleShape(event: MotionEvent): Boolean {
        val x = event.x; val y = event.y
        val shapeType = when (currentTool) {
            DrawingTool.RECTANGLE -> ShapeType.RECTANGLE
            DrawingTool.CIRCLE    -> ShapeType.CIRCLE
            DrawingTool.LINE      -> ShapeType.LINE
            DrawingTool.POLYGON   -> ShapeType.POLYGON
            else                  -> return false
        }
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                previewShape = WhiteboardShape(
                    id          = java.util.UUID.randomUUID().toString(),
                    type        = shapeType,
                    startX      = x, startY = y,
                    endX        = x, endY   = y,
                    color       = currentColor,
                    strokeWidth = strokeWidth,
                    sides       = polygonSides
                )
            }
            MotionEvent.ACTION_MOVE -> {
                previewShape?.let { it.endX = x; it.endY = y }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                previewShape?.let { s ->
                    s.endX = x; s.endY = y
                    onShapeFinished?.invoke(s)
                }
                previewShape = null
                invalidate()
            }
        }
        return true
    }

    // ── Text ─────────────────────────────────────────────────────────────────

    private fun handleText(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            onTextTapped?.invoke(event.x, event.y)
        }
        return true
    }

    // ── Select / drag text ────────────────────────────────────────────────────

    private fun handleSelect(event: MotionEvent): Boolean {
        val x = event.x; val y = event.y
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val hit = findTextAt(x, y)
                draggingTextId = hit?.id
                if (hit != null) { dragOffsetX = x - hit.x; dragOffsetY = y - hit.y }
            }
            MotionEvent.ACTION_MOVE -> {
                draggingTextId?.let { id ->
                    whiteboardState.texts.find { it.id == id }?.let {
                        it.x = x - dragOffsetX; it.y = y - dragOffsetY
                        invalidate()
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                draggingTextId?.let { id ->
                    whiteboardState.texts.find { it.id == id }?.let {
                        onTextMoved?.invoke(id, it.x, it.y)
                    }
                }
                draggingTextId = null
            }
        }
        return true
    }

    private fun findTextAt(x: Float, y: Float): WhiteboardText? {
        return whiteboardState.texts.lastOrNull { text ->
            val bounds = Rect()
            textPaint.textSize = text.fontSize
            textPaint.getTextBounds(text.text, 0, text.text.length, bounds)
            x in (text.x + bounds.left - 24f)..(text.x + bounds.right + 24f) &&
            y in (text.y + bounds.top  - 24f)..(text.y + bounds.bottom + 24f)
        }
    }

    // ─── PNG export ──────────────────────────────────────────────────────────

    fun exportBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c   = Canvas(bmp)
        c.drawColor(Color.WHITE)
        whiteboardState.strokes.forEach { renderStroke(c, it) }
        whiteboardState.shapes.forEach  { renderShape(c, it)  }
        whiteboardState.texts.forEach   { renderText(c, it)   }
        return bmp
    }
}
