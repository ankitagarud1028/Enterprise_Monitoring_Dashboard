import {
  Component, Input, Output, EventEmitter, OnInit, OnChanges,
  SimpleChanges, ChangeDetectionStrategy, signal, computed
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableColumn, PaginationConfig } from '../../models/dashboard.models';

@Component({
  selector: 'app-table',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnChanges {
  @Input({ required: true }) data: any[] = [];
  @Input({ required: true }) columns: TableColumn[] = [];
  @Input() pageSize = 10;
  @Input() title = '';
  @Output() rowAction = new EventEmitter<{ action: string; row: any }>();

  currentPage = signal(1);
  sortKey = signal('');
  sortDir = signal<'asc' | 'desc'>('asc');
  searchQuery = signal('');

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['data']) {
      this.currentPage.set(1);
    }
  }

  get filteredData(): any[] {
    let result = [...this.data];
    const q = this.searchQuery().toLowerCase();
    if (q) {
      result = result.filter(row =>
        this.columns.some(col => String(row[col.key] ?? '').toLowerCase().includes(q))
      );
    }
    if (this.sortKey()) {
      result.sort((a, b) => {
        const va = a[this.sortKey()];
        const vb = b[this.sortKey()];
        const cmp = va < vb ? -1 : va > vb ? 1 : 0;
        return this.sortDir() === 'asc' ? cmp : -cmp;
      });
    }
    return result;
  }

  get pagedData(): any[] {
    const start = (this.currentPage() - 1) * this.pageSize;
    return this.filteredData.slice(start, start + this.pageSize);
  }

  get totalPages(): number {
    return Math.ceil(this.filteredData.length / this.pageSize);
  }

  get pages(): number[] {
    const total = this.totalPages;
    const cur = this.currentPage();
    const pages: number[] = [];
    for (let i = Math.max(1, cur - 2); i <= Math.min(total, cur + 2); i++) {
      pages.push(i);
    }
    return pages;
  }

  sort(key: string): void {
    if (this.sortKey() === key) {
      this.sortDir.set(this.sortDir() === 'asc' ? 'desc' : 'asc');
    } else {
      this.sortKey.set(key);
      this.sortDir.set('asc');
    }
  }

  trackByIndex(index: number, item: any): any {
    return item?.id ?? index;
  }

  getBadgeClass(value: string): string {
    const map: Record<string, string> = {
      active: 'badge-danger', critical: 'badge-danger',
      warning: 'badge-warning',
      resolved: 'badge-success', online: 'badge-success',
      acknowledged: 'badge-warning', idle: 'badge-warning',
      info: 'badge-info', offline: 'badge-info'
    };
    return map[String(value).toLowerCase()] || 'badge-info';
  }
}
