import { Injectable } from '@angular/core';
import { Alert, ActiveUser, SystemMetric, KpiCard } from '../../shared/models/dashboard.models';

@Injectable({ providedIn: 'root' })
export class MockDataService {

  generateKpis(): KpiCard[] {
    return [
      {
        id: 'alerts',
        title: 'Total Alerts',
        value: Math.floor(Math.random() * 50) + 120,
        change: parseFloat((Math.random() * 20 - 10).toFixed(1)),
        changeType: Math.random() > 0.5 ? 'increase' : 'decrease',
        icon: 'notifications_active',
        color: '#ef4444',
        unit: ''
      },
      {
        id: 'users',
        title: 'Active Users',
        value: Math.floor(Math.random() * 100) + 450,
        change: parseFloat((Math.random() * 15).toFixed(1)),
        changeType: 'increase',
        icon: 'people',
        color: '#4f46e5',
        unit: ''
      },
      {
        id: 'health',
        title: 'System Health',
        value: (Math.random() * 5 + 94).toFixed(1),
        change: parseFloat((Math.random() * 2).toFixed(1)),
        changeType: 'increase',
        icon: 'monitor_heart',
        color: '#10b981',
        unit: '%'
      },
      {
        id: 'uptime',
        title: 'Uptime',
        value: '99.97',
        change: 0.02,
        changeType: 'increase',
        icon: 'schedule',
        color: '#06b6d4',
        unit: '%'
      }
    ];
  }

  generateAlerts(count = 50): Alert[] {
    const types: Alert['type'][] = ['critical', 'warning', 'info'];
    const statuses: Alert['status'][] = ['active', 'resolved', 'acknowledged'];
    const categories = ['Network', 'Database', 'Application', 'Security', 'Infrastructure'];
    const sources = ['Server-01', 'Server-02', 'DB-Primary', 'LB-Edge', 'Cache-Redis', 'API-Gateway'];
    const messages = [
      'High CPU usage detected on production server',
      'Memory threshold exceeded – 87% utilization',
      'Disk I/O latency spike above 200ms',
      'Database connection pool exhausted',
      'SSL certificate expiring in 7 days',
      'Unauthorized access attempt blocked',
      'API response time exceeds 2000ms',
      'Cache hit rate dropped below 60%',
      'Network packet loss detected – 3.2%',
      'Backup job failed – storage unreachable',
      'CPU temperature critical – 89°C',
      'Load balancer health check failed',
      'Service degradation on payment module',
      'Log aggregation lag detected',
      'Firewall rule triggered for IP 192.168.x.x'
    ];

    return Array.from({ length: count }, (_, i) => ({
      id: i + 1,
      type: types[Math.floor(Math.random() * types.length)],
      message: messages[Math.floor(Math.random() * messages.length)],
      source: sources[Math.floor(Math.random() * sources.length)],
      timestamp: new Date(Date.now() - Math.random() * 86400000 * 7),
      status: statuses[Math.floor(Math.random() * statuses.length)],
      category: categories[Math.floor(Math.random() * categories.length)]
    }));
  }

  generateMetric(): SystemMetric {
    return {
      timestamp: new Date(),
      cpu: Math.random() * 40 + 30,
      memory: Math.random() * 30 + 50,
      network: Math.random() * 60 + 20,
      disk: Math.random() * 20 + 40
    };
  }

  generateUsers(count = 30): ActiveUser[] {
    const names = ['Ankita Garud', 'Vicky Patil', 'Abhijit Garud', 'Nikita Patil', 'Priya Chore',
      'Swapanil Bhavar', 'Sam Rane', 'Rohit Jadhav', 'Komal Pawar', 'Adhira Kadam',
      'Pratiksha Kale', 'Riya Garud', 'Kunal Ghare', 'Samarth More ', 'Aniket Sanpkal'];
    const roles = ['Admin', 'Developer', 'Analyst', 'Manager', 'Support', 'DevOps'];
    const statuses: ActiveUser['status'][] = ['online', 'idle', 'offline'];
    const locations = ['Mumbai', 'Karad', 'Satara', 'Amravati', 'Pune', 'Mumbai', 'Kolhapur'];

    return names.slice(0, count).concat(
      Array.from({ length: Math.max(0, count - names.length) }, (_, i) => `User ${i + names.length + 1}`)
    ).map((name, i) => ({
      id: i + 1,
      name: typeof name === 'string' ? name : `User ${i + 1}`,
      email: `${(typeof name === 'string' ? name : `user${i + 1}`).toLowerCase().replace(' ', '.')}@company.com`,
      role: roles[Math.floor(Math.random() * roles.length)],
      status: statuses[Math.floor(Math.random() * statuses.length)],
      lastActivity: new Date(Date.now() - Math.random() * 3600000),
      location: locations[Math.floor(Math.random() * locations.length)],
      sessions: Math.floor(Math.random() * 5) + 1
    }));
  }
}
