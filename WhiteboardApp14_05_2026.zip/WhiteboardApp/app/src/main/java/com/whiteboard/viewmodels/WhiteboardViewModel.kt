package com.whiteboard.viewmodels

import android.graphics.Color
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.whiteboard.models.*
import java.util.Stack
import java.util.UUID

class WhiteboardViewModel : ViewModel() {

    // ─── Internal mutable lists (single source of truth) ─────────────────────

    private val strokes = mutableListOf<Stroke>()
    private val shapes  = mutableListOf<WhiteboardShape>()
    private val texts   = mutableListOf<WhiteboardText>()
    private var version   = 1
    private var createdAt = System.currentTimeMillis()

    // ─── LiveData ─────────────────────────────────────────────────────────────

    private val _state = MutableLiveData<WhiteboardState>()
    val state: LiveData<WhiteboardState> = _state

    // Post a fresh snapshot — always a new object, new list copies
    private fun postState() {
        _state.value = WhiteboardState(
            version   = version,
            createdAt = createdAt,
            strokes   = strokes.toMutableList(),   // ← NEW list copy every time
            shapes    = shapes.toMutableList(),
            texts     = texts.toMutableList()
        )
    }

    // For FileService: returns current data as a WhiteboardState
    fun currentState(): WhiteboardState = WhiteboardState(
        version   = version,
        createdAt = createdAt,
        strokes   = strokes.toMutableList(),
        shapes    = shapes.toMutableList(),
        texts     = texts.toMutableList()
    )

    // ─── Tool Settings ────────────────────────────────────────────────────────

    private val _currentTool  = MutableLiveData(DrawingTool.PEN)
    val currentTool: LiveData<DrawingTool> = _currentTool

    private val _currentColor = MutableLiveData(Color.BLACK)
    val currentColor: LiveData<Int> = _currentColor

    private val _strokeWidth  = MutableLiveData(6f)
    val strokeWidth: LiveData<Float> = _strokeWidth

    private val _fontSize     = MutableLiveData(40f)
    val fontSize: LiveData<Float> = _fontSize

    private val _eraserWidth  = MutableLiveData(40f)
    val eraserWidth: LiveData<Float> = _eraserWidth

    private val _polygonSides = MutableLiveData(6)
    val polygonSides: LiveData<Int> = _polygonSides

    // ─── UI Events ────────────────────────────────────────────────────────────

    private val _toastMessage = MutableLiveData<String?>()
    val toastMessage: LiveData<String?> = _toastMessage

    private val _canUndo = MutableLiveData(false)
    val canUndo: LiveData<Boolean> = _canUndo

    private val _canRedo = MutableLiveData(false)
    val canRedo: LiveData<Boolean> = _canRedo

    // ─── Undo / Redo stacks ───────────────────────────────────────────────────

    private val undoStack: Stack<UndoAction> = Stack()
    private val redoStack: Stack<UndoAction> = Stack()

    private fun pushUndo(action: UndoAction) {
        undoStack.push(action)
        redoStack.clear()
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = false
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val action = undoStack.pop()
        applyUndo(action)
        redoStack.push(action)
        postState()
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val action = redoStack.pop()
        applyRedo(action)
        undoStack.push(action)
        postState()
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    private fun applyUndo(action: UndoAction) {
        when (action) {
            is UndoAction.AddStroke    -> strokes.removeAll { it.id == action.stroke.id }
            is UndoAction.AddShape     -> shapes.removeAll  { it.id == action.shape.id  }
            is UndoAction.AddText      -> texts.removeAll   { it.id == action.text.id   }
            is UndoAction.RemoveStroke -> strokes.add(action.stroke)
            is UndoAction.RemoveShape  -> shapes.add(action.shape)
            is UndoAction.RemoveText   -> texts.add(action.text)
            is UndoAction.MoveText     -> {
                texts.find { it.id == action.text.id }?.let {
                    it.x = action.oldX; it.y = action.oldY
                }
            }
            is UndoAction.ClearAll -> { /* not undoable in simple impl */ }
        }
    }

    private fun applyRedo(action: UndoAction) {
        when (action) {
            is UndoAction.AddStroke    -> strokes.add(action.stroke)
            is UndoAction.AddShape     -> shapes.add(action.shape)
            is UndoAction.AddText      -> texts.add(action.text)
            is UndoAction.RemoveStroke -> strokes.removeAll { it.id == action.stroke.id }
            is UndoAction.RemoveShape  -> shapes.removeAll  { it.id == action.shape.id  }
            is UndoAction.RemoveText   -> texts.removeAll   { it.id == action.text.id   }
            is UndoAction.MoveText     -> {
                texts.find { it.id == action.text.id }?.let {
                    it.x = action.newX; it.y = action.newY
                }
            }
            is UndoAction.ClearAll -> {
                strokes.clear(); shapes.clear(); texts.clear()
            }
        }
    }

    // ─── Tool setters (do NOT post state — view updates directly) ────────────

    fun setTool(tool: DrawingTool)  { _currentTool.value  = tool }
    fun setColor(color: Int)        { _currentColor.value = color }
    fun setStrokeWidth(w: Float)    { _strokeWidth.value  = w }
    fun setFontSize(s: Float)       { _fontSize.value     = s }
    fun setEraserWidth(w: Float)    { _eraserWidth.value  = w }
    fun setPolygonSides(n: Int)     { _polygonSides.value = n }

    // ─── Drawing actions ──────────────────────────────────────────────────────


    fun addStroke(stroke: Stroke) {
        strokes.add(stroke)
        pushUndo(UndoAction.AddStroke(stroke))
        postState()   // ← posts NEW list copy — safe to render
    }


    fun addShape(shape: WhiteboardShape) {
        shapes.add(shape)
        pushUndo(UndoAction.AddShape(shape))
        postState()   // ← posts NEW snapshot that includes ALL previous strokes + this shape
    }

    fun addText(text: WhiteboardText) {
        texts.add(text)
        pushUndo(UndoAction.AddText(text))
        postState()
    }

    fun updateText(id: String, newContent: String) {
        texts.find { it.id == id }?.text = newContent
        postState()
    }

    fun moveText(id: String, newX: Float, newY: Float) {
        val text = texts.find { it.id == id } ?: return
        val oldX = text.x; val oldY = text.y
        text.x = newX; text.y = newY
        pushUndo(UndoAction.MoveText(text, oldX, oldY, newX, newY))
        postState()
    }

    fun removeText(id: String) {
        val text = texts.find { it.id == id } ?: return
        texts.remove(text)
        pushUndo(UndoAction.RemoveText(text))
        postState()
    }

    fun clearAll() {
        strokes.clear()
        shapes.clear()
        texts.clear()
        pushUndo(UndoAction.ClearAll)
        postState()
    }

    // ─── Load from file ───────────────────────────────────────────────────────

    fun loadState(newState: WhiteboardState) {
        strokes.clear();  strokes.addAll(newState.strokes)
        shapes.clear();   shapes.addAll(newState.shapes)
        texts.clear();    texts.addAll(newState.texts)
        version   = newState.version
        createdAt = newState.createdAt
        undoStack.clear()
        redoStack.clear()
        _canUndo.value = false
        _canRedo.value = false
        postState()
    }

    // ─── Helpers for creating new items ──────────────────────────────────────

    fun newText(x: Float, y: Float) = WhiteboardText(
        id       = UUID.randomUUID().toString(),
        text     = "",
        x        = x, y = y,
        color    = _currentColor.value ?: Color.BLACK,
        fontSize = _fontSize.value ?: 40f
    )

    fun showToast(msg: String) { _toastMessage.value = msg }
    fun clearToast()           { _toastMessage.value = null }
}
