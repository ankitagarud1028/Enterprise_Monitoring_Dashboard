import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { KpiCard } from '../../models/dashboard.models';

@Component({
  selector: 'app-kpi-card',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="kpi-card card">
      <div class="kpi-header">
        <div class="kpi-icon" [style.background]="card.color + '20'" [style.color]="card.color">
          <span class="material-icons">{{ card.icon }}</span>
        </div>
        <div class="kpi-change" [class.up]="card.changeType === 'increase'" [class.down]="card.changeType === 'decrease'">
          <span class="material-icons">{{ card.changeType === 'increase' ? 'trending_up' : 'trending_down' }}</span>
          {{ card.change > 0 ? '+' : '' }}{{ card.change }}%
        </div>
      </div>
      <div class="kpi-value">{{ card.value }}{{ card.unit }}</div>
      <div class="kpi-title">{{ card.title }}</div>
      <div class="kpi-bar">
        <div class="kpi-bar-fill" [style.width]="barWidth + '%'" [style.background]="card.color"></div>
      </div>
    </div>
  `,
  styles: [`
    .kpi-card {
      transition: transform 0.2s, box-shadow 0.2s;
      cursor: default;
      &:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-lg);
      }
    }
    .kpi-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 1rem;
    }
    .kpi-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      .material-icons { font-size: 1.5rem; }
    }
    .kpi-change {
      display: flex;
      align-items: center;
      gap: 0.2rem;
      font-size: 0.8rem;
      font-weight: 600;
      padding: 0.25rem 0.5rem;
      border-radius: 6px;
      .material-icons { font-size: 1rem; }
      &.up { color: #10b981; background: #d1fae5; }
      &.down { color: #ef4444; background: #fee2e2; }
    }
    .kpi-value {
      font-size: 2rem;
      font-weight: 700;
      color: var(--text);
      margin-bottom: 0.25rem;
      line-height: 1;
    }
    .kpi-title {
      font-size: 0.875rem;
      color: var(--text-muted);
      margin-bottom: 1rem;
    }
    .kpi-bar {
      height: 4px;
      background: var(--surface-2);
      border-radius: 2px;
      overflow: hidden;
    }
    .kpi-bar-fill {
      height: 100%;
      border-radius: 2px;
      transition: width 0.5s ease;
    }
  `]
})
export class KpiCardComponent {
  @Input({ required: true }) card!: KpiCard;
  get barWidth(): number {
    const val = parseFloat(String(this.card.value));
    return Math.min(100, isNaN(val) ? 70 : val > 100 ? 80 : val);
  }
}
