import {
  Component, Input, OnChanges, SimpleChanges, ViewChild, ElementRef,
  AfterViewInit, ChangeDetectionStrategy, OnDestroy
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Chart, ChartConfiguration, ChartType, registerables } from 'chart.js';

Chart.register(...registerables);

@Component({
  selector: 'app-chart',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="chart-container card">
      <div class="chart-header">
        <h3 class="chart-title">{{ title }}</h3>
        @if (subtitle) { <p class="chart-subtitle">{{ subtitle }}</p> }
      </div>
      <div class="chart-body" [style.height]="height + 'px'">
        <canvas #canvas></canvas>
      </div>
    </div>
  `,
  styles: [`
    .chart-container { padding: 1.25rem; }
    .chart-header { margin-bottom: 1rem; }
    .chart-title { font-size: 1rem; font-weight: 600; color: var(--text); }
    .chart-subtitle { font-size: 0.8rem; color: var(--text-muted); margin-top: 0.2rem; }
    .chart-body { position: relative; }
    canvas { width: 100% !important; }
  `]
})
export class ChartComponent implements AfterViewInit, OnChanges, OnDestroy {
  @ViewChild('canvas') canvasRef!: ElementRef<HTMLCanvasElement>;
  @Input({ required: true }) type!: ChartType;
  @Input({ required: true }) data: any;
  @Input() options: any = {};
  @Input() title = '';
  @Input() subtitle = '';
  @Input() height = 250;

  private chart?: Chart;

  ngAfterViewInit(): void {
    this.createChart();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.chart && changes['data']) {
      this.chart.data = this.data;
      this.chart.update('active');
    }
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }

  private createChart(): void {
    if (!this.canvasRef) return;
    this.chart?.destroy();

    const defaultOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: { color: '#64748b', font: { family: 'Inter', size: 12 } }
        }
      },
      scales: this.type === 'pie' || this.type === 'doughnut' ? undefined : {
        x: {
          grid: { color: 'rgba(100,116,139,0.1)' },
          ticks: { color: '#64748b', font: { family: 'Inter', size: 11 } }
        },
        y: {
          grid: { color: 'rgba(100,116,139,0.1)' },
          ticks: { color: '#64748b', font: { family: 'Inter', size: 11 } }
        }
      }
    };

    this.chart = new Chart(this.canvasRef.nativeElement, {
      type: this.type,
      data: this.data,
      options: { ...defaultOptions, ...this.options }
    });
  }
}
