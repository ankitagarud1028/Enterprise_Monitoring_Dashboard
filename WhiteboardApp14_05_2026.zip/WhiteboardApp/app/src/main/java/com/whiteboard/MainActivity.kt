package com.whiteboard

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.Slider
import com.whiteboard.models.DrawingTool
import com.whiteboard.services.FileService
import com.whiteboard.viewmodels.WhiteboardViewModel
import com.whiteboard.views.WhiteboardView
import java.io.File

class MainActivity : AppCompatActivity() {

    private val vm: WhiteboardViewModel by viewModels()
    private lateinit var fileService: FileService

    private lateinit var whiteboardView: WhiteboardView
    private lateinit var toolPen:     ImageButton
    private lateinit var toolEraser:  ImageButton
    private lateinit var toolRect:    ImageButton
    private lateinit var toolCircle:  ImageButton
    private lateinit var toolLine:    ImageButton
    private lateinit var toolPolygon: ImageButton
    private lateinit var toolText:    ImageButton
    private lateinit var toolSelect:  ImageButton
    private lateinit var btnUndo:     ImageButton
    private lateinit var btnRedo:     ImageButton
    private lateinit var btnClear:    ImageButton
    private lateinit var btnSave:     ImageButton
    private lateinit var btnLoad:     ImageButton
    private lateinit var btnExport:   ImageButton
    private lateinit var colorPalette: LinearLayout
    private lateinit var sliderStroke: Slider
    private lateinit var tvCurrentTool: TextView

    private var currentFileName: String? = null

    private val filePickerLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri ?: return@registerForActivityResult
            val state = fileService.loadWhiteboardFromUri(uri)
            if (state != null) {
                vm.loadState(state)
                currentFileName = null
                Toast.makeText(this, "Whiteboard loaded", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Failed to load file", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        setContentView(R.layout.activity_main)

        fileService = FileService(this)

        bindViews()
        setupCanvas()
        setupToolbar()
        setupColorPalette()
        setupSlider()
        observeViewModel()
    }

    private fun bindViews() {
        whiteboardView = findViewById(R.id.whiteboardView)
        toolPen        = findViewById(R.id.btnToolPen)
        toolEraser     = findViewById(R.id.btnToolEraser)
        toolRect       = findViewById(R.id.btnToolRect)
        toolCircle     = findViewById(R.id.btnToolCircle)
        toolLine       = findViewById(R.id.btnToolLine)
        toolPolygon    = findViewById(R.id.btnToolPolygon)
        toolText       = findViewById(R.id.btnToolText)
        toolSelect     = findViewById(R.id.btnToolSelect)
        btnUndo        = findViewById(R.id.btnUndo)
        btnRedo        = findViewById(R.id.btnRedo)
        btnClear       = findViewById(R.id.btnClear)
        btnSave        = findViewById(R.id.btnSave)
        btnLoad        = findViewById(R.id.btnLoad)
        btnExport      = findViewById(R.id.btnExport)
        colorPalette   = findViewById(R.id.colorPalette)
        sliderStroke   = findViewById(R.id.sliderStroke)
        tvCurrentTool  = findViewById(R.id.tvCurrentTool)
    }

    private fun setupCanvas() {
        // Stroke/eraser finished → add to ViewModel state (this triggers setState via observer)
        whiteboardView.onStrokeFinished = { stroke -> vm.addStroke(stroke) }
        whiteboardView.onShapeFinished  = { shape  -> vm.addShape(shape)  }

        whiteboardView.onTextTapped = { x, y ->
            showTextInputDialog(x, y)
        }
        whiteboardView.onTextMoved = { id, newX, newY ->
            vm.moveText(id, newX, newY)
        }
    }

    private fun setupToolbar() {
        val toolMap = mapOf(
            toolPen     to DrawingTool.PEN,
            toolEraser  to DrawingTool.ERASER,
            toolRect    to DrawingTool.RECTANGLE,
            toolCircle  to DrawingTool.CIRCLE,
            toolLine    to DrawingTool.LINE,
            toolPolygon to DrawingTool.POLYGON,
            toolText    to DrawingTool.TEXT,
            toolSelect  to DrawingTool.SELECT
        )
        toolMap.forEach { (btn, tool) ->
            btn.setOnClickListener {
                vm.setTool(tool)
                whiteboardView.currentTool = tool
                highlightTool(btn)
                tvCurrentTool.text = tool.name
            }
        }

        btnUndo.setOnClickListener   { vm.undo() }
        btnRedo.setOnClickListener   { vm.redo() }
        btnClear.setOnClickListener  { confirmClear() }
        btnSave.setOnClickListener   { saveWhiteboard() }
        btnLoad.setOnClickListener   { showLoadDialog() }
        btnExport.setOnClickListener { exportPng() }

        highlightTool(toolPen)
    }

    private fun highlightTool(selected: ImageButton) {
        listOf(toolPen, toolEraser, toolRect, toolCircle, toolLine,
            toolPolygon, toolText, toolSelect).forEach {
            it.setBackgroundColor(Color.TRANSPARENT)
        }
        selected.setBackgroundColor(Color.parseColor("#44000000"))
    }

    private val palette = listOf(
        "#000000", "#E53935", "#1E88E5",
        "#43A047", "#FB8C00", "#8E24AA", "#FFFFFF"
    )

    private fun setupColorPalette() {
        palette.forEach { hex ->
            val color = Color.parseColor(hex)
            val dot = android.view.View(this).apply {
                val size = (48 * resources.displayMetrics.density).toInt()
                layoutParams = LinearLayout.LayoutParams(size, size).also {
                    it.setMargins(6, 6, 6, 6)
                }
                setBackgroundColor(color)
                // Add border for white swatch so it's visible
                if (hex == "#FFFFFF") {
                    background = android.graphics.drawable.GradientDrawable().also { gd ->
                        gd.setColor(color)
                        gd.setStroke(2, Color.LTGRAY)
                    }
                }
                setOnClickListener {
                    vm.setColor(color)
                    whiteboardView.currentColor = color
                }
            }
            colorPalette.addView(dot)
        }
    }

    private fun setupSlider() {
        sliderStroke.valueFrom = 2f
        sliderStroke.valueTo   = 80f
        sliderStroke.value     = 6f
        sliderStroke.addOnChangeListener { _, value, fromUser ->
            if (!fromUser) return@addOnChangeListener
            if (vm.currentTool.value == DrawingTool.ERASER) {
                vm.setEraserWidth(value)
                whiteboardView.eraserWidth = value
            } else {
                vm.setStrokeWidth(value)
                whiteboardView.strokeWidth = value
            }
        }
    }

    private fun observeViewModel() {
        //ONLY call setState() when actual DATA changes, not tool/color/width
        vm.state.observe(this) { state ->
            whiteboardView.setState(state)
        }

        // Tool/color/width observers just update WhiteboardView properties directly
        // (no setState call here — that's the key fix)
        vm.currentTool.observe(this)  { tool ->
            whiteboardView.currentTool = tool
            tvCurrentTool.text = tool.name
        }
        vm.currentColor.observe(this) { color -> whiteboardView.currentColor = color }
        vm.strokeWidth.observe(this)  { w     -> whiteboardView.strokeWidth  = w     }
        vm.eraserWidth.observe(this)  { w     -> whiteboardView.eraserWidth  = w     }
        vm.fontSize.observe(this)     { s     -> whiteboardView.fontSize     = s     }
        vm.polygonSides.observe(this) { n     -> whiteboardView.polygonSides = n     }

        vm.canUndo.observe(this) { can -> btnUndo.alpha = if (can) 1f else 0.4f }
        vm.canRedo.observe(this) { can -> btnRedo.alpha = if (can) 1f else 0.4f }

        vm.toastMessage.observe(this) { msg ->
            msg?.let {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
                vm.clearToast()
            }
        }
    }

    private fun showTextInputDialog(x: Float, y: Float) {
        val input = EditText(this).apply {
            hint     = "Type here…"
            textSize = 18f
            setPadding(32, 16, 32, 16)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Insert Text")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val txt = input.text.toString().trim()
                if (txt.isNotEmpty()) {
                    vm.addText(vm.newText(x, y).copy(text = txt))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmClear() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Clear Canvas")
            .setMessage("This will erase everything. Continue?")
            .setPositiveButton("Clear") { _, _ -> vm.clearAll() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveWhiteboard() {
        val path = fileService.saveWhiteboard(vm.currentState(), currentFileName)
        currentFileName = File(path).name
        vm.showToast("Saved: $currentFileName")
    }

    private fun showLoadDialog() {
        val files = fileService.listSavedWhiteboards()
        if (files.isEmpty()) {
            MaterialAlertDialogBuilder(this)
                .setTitle("No saved whiteboards")
                .setPositiveButton("Load from file") { _, _ ->
                    filePickerLauncher.launch("application/json")
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }
        val names = files.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Load Whiteboard")
            .setItems(names) { _, i ->
                val state = fileService.loadWhiteboard(files[i].absolutePath)
                if (state != null) {
                    vm.loadState(state)
                    currentFileName = files[i].name
                    vm.showToast("Loaded: ${files[i].name}")
                } else {
                    vm.showToast("Failed to load")
                }
            }
            .setNeutralButton("Pick file…") { _, _ ->
                filePickerLauncher.launch("application/json")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exportPng() {
        val bitmap = whiteboardView.exportBitmap()
        val path   = fileService.exportAsPng(bitmap)
        vm.showToast("Exported to $path")
    }
}
